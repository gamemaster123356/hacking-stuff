#!/usr/bin/env bash

#==============================
#            Colors
#==============================
nc="\x1B[0m"              # Noclor      ${nc}
red="\x1B[1;31m"          # Red         ${red}
green="\x1B[1;32m"        # Green       ${green}
yellow="\x1B[1;33m"       # Yellow      ${yellow}
blue="\x1B[1;34m"         # Blue        ${blue}
purple="\x1B[1;35m"       # Purple      ${purple}
cyan="\x1B[1;36m"         # Cyan        ${cyan}
lightgray="\x1B[1;37m"    # LightGray   ${lightgray}
black="\x1B[0;30m"        # Black       ${black}
darkgray="\x1B[1;30m"     # DarkGray    ${darkgray}
darkred="\x1B[0;31m"      # DarkRed     ${darkred}
darkgreen="\x1B[0;32m"    # DarkGreen   ${darkgreen}
brown="\x1B[0;33m"        # Brown       ${brown}
darkblue="\x1B[0;34m"     # DarkBlue    ${darkblue}
darkpurple="\x1B[0;35m"   # DarkPurple  ${darkpurple}
darkcyan="\x1B[0;36m"     # DarkCyan    ${darkcyan}
white="\x1B[1;37m"        # White       ${white}

#==============================
#            UI
#==============================
checkm="\u2714"                         # Check Mark  ${checkm}
crossm="\u2716"                         # Cross Mark  ${crossm}

function jmpto
{
    label=$1
    cmd=$(sed -n "/$label:/{:a;n;p;ba};" $0 | grep -v ':$')
    eval "$cmd"
    exit
}

jmpto start
start:

menu:
menu=menu
clear
seldone=""
echo -e "${blue}\x20\x20\x20\x5F\x5F\x5F\x5F\x5F\x20\x5F\x5F\x20\x20\x5F\x5F\x20\x20\x5F\x5F\x5F\x5F\x5F\x20\x5F\x5F\x5F\x5F\x5F\x5F\x20\x5F\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x5F\x20"
echo -e "${blue}\x20\x20\x2F\x20\x5F\x5F\x5F\x5F\x7C\x20\x20\x5C\x2F\x20\x20\x7C\x2F\x20\x5F\x5F\x5F\x5F\x7C\x20\x20\x5F\x5F\x5F\x5F\x28\x5F\x29\x20\x20\x20\x20\x20\x20\x20\x20\x20\x7C\x20\x7C"
echo -e "${blue}\x20\x7C\x20\x7C\x20\x20\x20\x20\x7C\x20\x5C\x20\x20\x2F\x20\x7C\x20\x28\x5F\x5F\x5F\x20\x7C\x20\x7C\x5F\x5F\x20\x20\x20\x5F\x20\x5F\x20\x5F\x5F\x20\x20\x20\x5F\x5F\x7C\x20\x7C"
echo -e "${blue}\x20\x7C\x20\x7C\x20\x20\x20\x20\x7C\x20\x7C\x5C\x2F\x7C\x20\x7C\x5C\x5F\x5F\x5F\x20\x5C\x7C\x20\x20\x5F\x5F\x7C\x20\x7C\x20\x7C\x20\x27\x5F\x20\x5C\x20\x2F\x20\x5F\x60\x20\x7C"
echo -e "${blue}\x20\x7C\x20\x7C\x5F\x5F\x5F\x5F\x7C\x20\x7C\x20\x20\x7C\x20\x7C\x5F\x5F\x5F\x5F\x29\x20\x7C\x20\x7C\x20\x20\x20\x20\x7C\x20\x7C\x20\x7C\x20\x7C\x20\x7C\x20\x28\x5F\x7C\x20\x7C"
echo -e "${blue}\x20\x20\x5C\x5F\x5F\x5F\x5F\x5F\x7C\x5F\x7C\x20\x20\x7C\x5F\x7C\x5F\x5F\x5F\x5F\x5F\x2F\x7C\x5F\x7C\x20\x20\x20\x20\x7C\x5F\x7C\x5F\x7C\x20\x7C\x5F\x7C\x5C\x5F\x5F\x2C\x5F\x7C"
echo -e ""
echo -e "${purple}\x20Main\x20Menu"
echo -e ""
echo -e "${yellow}1. Dir/FileList Big"
echo -e "${yellow}2. Dir/FileList Common"
echo -e "${yellow}3. Dir/FileList Small ${red}"
echo -e ""
echo -e "${yellow}0. Exit CMDFind"
echo -e "${red}"
read -p "type a number/letter: " selnum

if [[ "$selnum" == "" ]]
then
  jmpto menu
fi

if [[ "$selnum" == "0" ]]
then
  exit
fi

if [[ "$selnum" == "1" ]]
then
   menu1:
   menu="menu1"
   clear
   hseldone=""
   echo -e "${blue}\x20\x20\x20\x5F\x5F\x5F\x5F\x5F\x20\x5F\x5F\x20\x20\x5F\x5F\x20\x20\x5F\x5F\x5F\x5F\x5F\x20\x5F\x5F\x5F\x5F\x5F\x5F\x20\x5F\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x5F\x20"
   echo -e "${blue}\x20\x20\x2F\x20\x5F\x5F\x5F\x5F\x7C\x20\x20\x5C\x2F\x20\x20\x7C\x2F\x20\x5F\x5F\x5F\x5F\x7C\x20\x20\x5F\x5F\x5F\x5F\x28\x5F\x29\x20\x20\x20\x20\x20\x20\x20\x20\x20\x7C\x20\x7C"
   echo -e "${blue}\x20\x7C\x20\x7C\x20\x20\x20\x20\x7C\x20\x5C\x20\x20\x2F\x20\x7C\x20\x28\x5F\x5F\x5F\x20\x7C\x20\x7C\x5F\x5F\x20\x20\x20\x5F\x20\x5F\x20\x5F\x5F\x20\x20\x20\x5F\x5F\x7C\x20\x7C"
   echo -e "${blue}\x20\x7C\x20\x7C\x20\x20\x20\x20\x7C\x20\x7C\x5C\x2F\x7C\x20\x7C\x5C\x5F\x5F\x5F\x20\x5C\x7C\x20\x20\x5F\x5F\x7C\x20\x7C\x20\x7C\x20\x27\x5F\x20\x5C\x20\x2F\x20\x5F\x60\x20\x7C"
   echo -e "${blue}\x20\x7C\x20\x7C\x5F\x5F\x5F\x5F\x7C\x20\x7C\x20\x20\x7C\x20\x7C\x5F\x5F\x5F\x5F\x29\x20\x7C\x20\x7C\x20\x20\x20\x20\x7C\x20\x7C\x20\x7C\x20\x7C\x20\x7C\x20\x28\x5F\x7C\x20\x7C"
   echo -e "${blue}\x20\x20\x5C\x5F\x5F\x5F\x5F\x5F\x7C\x5F\x7C\x20\x20\x7C\x5F\x7C\x5F\x5F\x5F\x5F\x5F\x2F\x7C\x5F\x7C\x20\x20\x20\x20\x7C\x5F\x7C\x5F\x7C\x20\x7C\x5F\x7C\x5C\x5F\x5F\x2C\x5F\x7C"
   echo -e ""
   echo -e "${purple}\x20Dir/FileList\x20Big\x20Menu"
   echo -e ""
   echo -e "${yellow}1. 1.txt"
   echo -e "${yellow}2. asp.txt"
   echo -e "${yellow}3. aspx.txt"
   echo -e "${yellow}4. cfm.txt"
   echo -e "${yellow}5. cgi.txt"
   echo -e "${yellow}6. customsuffix.txt"
   echo -e "${yellow}7. dir.txt"
   echo -e "${yellow}8. dir2.txt"
   echo -e "${yellow}9. discuzbackup.txt"
   echo -e "${yellow}10. ewebeditor.txt"
   echo -e "${yellow}11. fck.txt"
   echo -e "${yellow}12. jsp.txt"
   echo -e "${yellow}13. mdb.txt"
   echo -e "${yellow}14. php.txt"
   echo -e "${yellow}15. phpmyadmin.txt"
   echo -e "${yellow}16. pl.txt"
   echo -e "${yellow}17. rarfeatured.txt"
   echo -e "${yellow}18. tar.gzfeatured.txt"
   echo -e "${yellow}19. wwwscan.txt ${red}"
   echo -e ""
   echo -e "${yellow}0. Exit CMDFind"
   echo -e "${yellow}A. Main Menu"
   echo -e "${red}"
   read -p "type a number/letter: " hselnum

   if [[ "$hselnum" == "" ]]
   then
     jmpto menu1
   fi

   if [[ "$hselnum" == "0" ]]
   then
     exit
   fi

   if [[ "$hselnum" == "A" ]]
   then
     jmpto menu
   fi

   # ------------------------#
   #       main START        #
   # ------------------------#

   if [[ "$hselnum" == "1" ]]
   then
     hseldone="1"
     hfile="data/dic-big/1.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "2" ]]
   then
     hseldone="1"
     hfile="data/dic-big/asp.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "3" ]]
   then
     hseldone="1"
     hfile="data/dic-big/aspx.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "4" ]]
   then
     hseldone="1"
     hfile="data/dic-big/cfm.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "5" ]]
   then
     hseldone="1"
     hfile="data/dic-big/cgi.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "6" ]]
   then
     hseldone="1"
     hfile="data/dic-big/customsuffix.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "7" ]]
   then
     hseldone="1"
     hfile="data/dic-big/dir.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "8" ]]
   then
     hseldone="1"
     hfile="data/dic-big/dir2.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "9" ]]
   then
     hseldone="1"
     hfile="data/dic-big/discuzbackup.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "10" ]]
   then
     hseldone="1"
     hfile="data/dic-big/ewebeditor.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "11" ]]
   then
     hseldone="1"
     hfile="data/dic-big/fck.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "12" ]]
   then
     hseldone="1"
     hfile="data/dic-big/jsp.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "13" ]]
   then
     hseldone="1"
     hfile="data/dic-big/mdb.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "14" ]]
   then
     hseldone="1"
     hfile="data/dic-big/php.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "15" ]]
   then
     hseldone="1"
     hfile="data/dic-big/phpmyadmin.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "16" ]]
   then
     hseldone="1"
     hfile="data/dic-big/pl.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "17" ]]
   then
     hseldone="1"
     hfile="data/dic-big/rarfeatured.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "18" ]]
   then
     hseldone="1"
     hfile="data/dic-big/tar.gzfeatured.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "19" ]]
   then
     hseldone="1"
     hfile="data/dic-big/wwwscan.txt"
     jmpto scan
   fi

   # ------------------------#
   #        main END         #
   # ------------------------#

   if [[ "$hseldone" == "" ]]
   then
     clear
     echo -e "${red}[$crossm] Please provide a valid number/letter!"
     read -p 'Press any key to continue: '
     jmpto ${menu}
   fi
fi

if [[ "$selnum" == "2" ]]
then
   menu2:
   menu="menu2"
   clear
   hseldone=""
   echo -e "${blue}\x20\x20\x20\x5F\x5F\x5F\x5F\x5F\x20\x5F\x5F\x20\x20\x5F\x5F\x20\x20\x5F\x5F\x5F\x5F\x5F\x20\x5F\x5F\x5F\x5F\x5F\x5F\x20\x5F\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x5F\x20"
   echo -e "${blue}\x20\x20\x2F\x20\x5F\x5F\x5F\x5F\x7C\x20\x20\x5C\x2F\x20\x20\x7C\x2F\x20\x5F\x5F\x5F\x5F\x7C\x20\x20\x5F\x5F\x5F\x5F\x28\x5F\x29\x20\x20\x20\x20\x20\x20\x20\x20\x20\x7C\x20\x7C"
   echo -e "${blue}\x20\x7C\x20\x7C\x20\x20\x20\x20\x7C\x20\x5C\x20\x20\x2F\x20\x7C\x20\x28\x5F\x5F\x5F\x20\x7C\x20\x7C\x5F\x5F\x20\x20\x20\x5F\x20\x5F\x20\x5F\x5F\x20\x20\x20\x5F\x5F\x7C\x20\x7C"
   echo -e "${blue}\x20\x7C\x20\x7C\x20\x20\x20\x20\x7C\x20\x7C\x5C\x2F\x7C\x20\x7C\x5C\x5F\x5F\x5F\x20\x5C\x7C\x20\x20\x5F\x5F\x7C\x20\x7C\x20\x7C\x20\x27\x5F\x20\x5C\x20\x2F\x20\x5F\x60\x20\x7C"
   echo -e "${blue}\x20\x7C\x20\x7C\x5F\x5F\x5F\x5F\x7C\x20\x7C\x20\x20\x7C\x20\x7C\x5F\x5F\x5F\x5F\x29\x20\x7C\x20\x7C\x20\x20\x20\x20\x7C\x20\x7C\x20\x7C\x20\x7C\x20\x7C\x20\x28\x5F\x7C\x20\x7C"
   echo -e "${blue}\x20\x20\x5C\x5F\x5F\x5F\x5F\x5F\x7C\x5F\x7C\x20\x20\x7C\x5F\x7C\x5F\x5F\x5F\x5F\x5F\x2F\x7C\x5F\x7C\x20\x20\x20\x20\x7C\x5F\x7C\x5F\x7C\x20\x7C\x5F\x7C\x5C\x5F\x5F\x2C\x5F\x7C"
   echo -e ""
   echo -e "${purple}\x20Dir/FileList\x20Common\x20Menu"
   echo -e ""
   echo -e "${yellow}1. asp.txt"
   echo -e "${yellow}2. aspx.txt"
   echo -e "${yellow}3. common.txt"
   echo -e "${yellow}4. jsp.txt"
   echo -e "${yellow}5. php.txt ${red}"
   echo -e ""
   echo -e "${yellow}0. Exit CMDFind"
   echo -e "${yellow}A. Main Menu"
   echo -e "${red}"
   read -p "type a number/letter: " hselnum

   if [[ "$hselnum" == "" ]]
   then
     jmpto menu2
   fi

   if [[ "$hselnum" == "0" ]]
   then
     exit
   fi

   if [[ "$hselnum" == "A" ]]
   then
     jmpto menu
   fi

   # ------------------------#
   #       main START        #
   # ------------------------#

   if [[ "$hselnum" == "1" ]]
   then
     hseldone="1"
     hfile="data/dic-common/asp.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "2" ]]
   then
     hseldone="1"
     hfile="data/dic-common/aspx.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "3" ]]
   then
     hseldone="1"
     hfile="data/dic-common/common.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "4" ]]
   then
     hseldone="1"
     hfile="data/dic-common/jsp.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "5" ]]
   then
     hseldone="1"
     hfile="data/dic-common/php.txt"
     jmpto scan
   fi

   # ------------------------#
   #        main END         #
   # ------------------------#

   if [[ "$hseldone" == "" ]]
   then
     clear
     echo -e "${red}[$crossm] Please provide a valid number/letter!"
     read -p 'Press any key to continue: '
     jmpto ${menu}
   fi
fi

if [[ "$selnum" == "3" ]]
then
   menu3:
   menu="menu3"
   clear
   hseldone=""
   echo -e "${blue}\x20\x20\x20\x5F\x5F\x5F\x5F\x5F\x20\x5F\x5F\x20\x20\x5F\x5F\x20\x20\x5F\x5F\x5F\x5F\x5F\x20\x5F\x5F\x5F\x5F\x5F\x5F\x20\x5F\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x5F\x20"
   echo -e "${blue}\x20\x20\x2F\x20\x5F\x5F\x5F\x5F\x7C\x20\x20\x5C\x2F\x20\x20\x7C\x2F\x20\x5F\x5F\x5F\x5F\x7C\x20\x20\x5F\x5F\x5F\x5F\x28\x5F\x29\x20\x20\x20\x20\x20\x20\x20\x20\x20\x7C\x20\x7C"
   echo -e "${blue}\x20\x7C\x20\x7C\x20\x20\x20\x20\x7C\x20\x5C\x20\x20\x2F\x20\x7C\x20\x28\x5F\x5F\x5F\x20\x7C\x20\x7C\x5F\x5F\x20\x20\x20\x5F\x20\x5F\x20\x5F\x5F\x20\x20\x20\x5F\x5F\x7C\x20\x7C"
   echo -e "${blue}\x20\x7C\x20\x7C\x20\x20\x20\x20\x7C\x20\x7C\x5C\x2F\x7C\x20\x7C\x5C\x5F\x5F\x5F\x20\x5C\x7C\x20\x20\x5F\x5F\x7C\x20\x7C\x20\x7C\x20\x27\x5F\x20\x5C\x20\x2F\x20\x5F\x60\x20\x7C"
   echo -e "${blue}\x20\x7C\x20\x7C\x5F\x5F\x5F\x5F\x7C\x20\x7C\x20\x20\x7C\x20\x7C\x5F\x5F\x5F\x5F\x29\x20\x7C\x20\x7C\x20\x20\x20\x20\x7C\x20\x7C\x20\x7C\x20\x7C\x20\x7C\x20\x28\x5F\x7C\x20\x7C"
   echo -e "${blue}\x20\x20\x5C\x5F\x5F\x5F\x5F\x5F\x7C\x5F\x7C\x20\x20\x7C\x5F\x7C\x5F\x5F\x5F\x5F\x5F\x2F\x7C\x5F\x7C\x20\x20\x20\x20\x7C\x5F\x7C\x5F\x7C\x20\x7C\x5F\x7C\x5C\x5F\x5F\x2C\x5F\x7C"
   echo -e ""
   echo -e "${purple}\x20DirList\x20Small\x20Menu"
   echo -e ""
   echo -e "${yellow}1. asp.txt"
   echo -e "${yellow}2. aspx.txt"
   echo -e "${yellow}3. dir.txt"
   echo -e "${yellow}4. jsp.txt"
   echo -e "${yellow}5. mdb.txt"
   echo -e "${yellow}6. php.txt ${red}"
   echo -e ""
   echo -e "${yellow}0. Exit CMDFind"
   echo -e "${yellow}A. Main Menu"
   echo -e "${red}"
   read -p "type a number/letter: " hselnum

   if [[ "$hselnum" == "" ]]
   then
     jmpto menu3
   fi

   if [[ "$hselnum" == "0" ]]
   then
     exit
   fi

   if [[ "$hselnum" == "A" ]]
   then
     jmpto menu
   fi

   # ------------------------#
   #       main START        #
   # ------------------------#

   if [[ "$hselnum" == "1" ]]
   then
     hseldone="1"
     hfile="data/dic-small/asp.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "2" ]]
   then
     hseldone="1"
     hfile="data/dic-small/aspx.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "3" ]]
   then
     hseldone="1"
     hfile="data/dic-small/dir.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "4" ]]
   then
     hseldone="1"
     hfile="data/dic-small/jsp.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "5" ]]
   then
     hseldone="1"
     hfile="data/dic-small/mdb.txt"
     jmpto scan
   fi

   if [[ "$hselnum" == "6" ]]
   then
     hseldone="1"
     hfile="data/dic-small/php.txt"
     jmpto scan
   fi

   # ------------------------#
   #        main END         #
   # ------------------------#

   if [[ "$hseldone" == "" ]]
   then
     clear
     echo -e "${red}[$crossm] Please provide a valid number/letter!"
     read -p 'Press any key to continue: '
     jmpto ${menu}
   fi
fi


if [[ "$hseldone" == "" ]]
then
  clear
  echo -e "${red}[$crossm] Please provide a valid number/letter!"
  read -p 'Press any key to continue: '
  jmpto ${menu}
fi


scan:
echo -e "${yellow}[!] Please type the url you want to scan"
echo -e "${red}(DO NOT PUT IT WITH https:// or http://)${purple}"
read -p "Type the Url: " url

if [ -z "$url" ]
then
  echo -e "${red}[$crossm] Please type a valid url!..."
  read -p 'Press any key to continue: '
  jmpto ${menu}
fi

# Check for which protocal to use
if wget --spider https://$url 2>/dev/null; then
  protocal="https"
else
  protocal="http"
fi

# Validate URL
if ! curl --output /dev/null --silent --head --fail "$protocal://$url"; then
  echo -e "${red}[$crossm] Please type a valid url!..."
  read -p 'Press any key to continue: '
  jmpto ${menu}
fi

echo -e ""
echo -e "${yellow}[!] Please wait scanning..."
echo -e "${yellow}PS: it only shows the dirs/files which exist"
echo -e ""

hressucces="0"

# do loop
while IFS= read -r line; do
  hres=`curl -L -o /dev/null -u myself:XXXXXX -Isw '%{http_code}\n' http://{$url}/{$line}`

  if [[ "$hres" == "200" ]] || [[ "$hres" == "401" ]] || [[ "$hres" == "403" ]] || [[ "$hres" == "405" ]] || [[ "$hres" == "301" ]] 
  then
    hressucces="1"
    if [[ "$hres" == "200" ]]
    then
      echo -e "${green}-----------------------------------------"
      echo -e "${green}Host: ${url}"
      echo -e "${green}Found: ${line}"
      echo -e "${green}HTTP-Status: ${hres}"
      echo -e "${green}-----------------------------------------"
    elif [[ "$hres" == "301" ]]
    then
      echo -e "${darkpurple}-----------------------------------------"
      echo -e "${darkpurple}Host: ${url}"
      echo -e "${darkpurple}Found: ${line}"
      echo -e "${darkpurple}HTTP-Status: ${hres}"
      echo -e "${darkpurple}-----------------------------------------"
    elif [[ "$hres" == "401" ]]
    then
      echo -e "${darkcyan}-----------------------------------------"
      echo -e "${darkcyan}Host: ${url}"
      echo -e "${darkcyan}Found: ${line}"
      echo -e "${darkcyan}HTTP-Status: ${hres}"
      echo -e "${darkcyan}-----------------------------------------"
    elif [[ "$hres" == "403" ]]
    then
      echo -e "${brown}-----------------------------------------"
      echo -e "${brown}Host: ${url}"
      echo -e "${brown}Found: ${line}"
      echo -e "${brown}HTTP-Status: ${hres}"
      echo -e "${brown}-----------------------------------------"
    elif [[ "$hres" == "405" ]]
    then
      echo -e "${yellow}-----------------------------------------"
      echo -e "${yellow}Host: ${url}"
      echo -e "${yellow}Found: ${line}"
      echo -e "${yellow}HTTP-Status: ${hres}"
      echo -e "${yellow}-----------------------------------------"
    else
      echo -e "${lightgray}-----------------------------------------"
      echo -e "${lightgray}Host: ${url}"
      echo -e "${lightgray}Found: ${line}"
      echo -e "${lightgray}HTTP-Status: ${hres}"
      echo -e "${lightgray}-----------------------------------------"
    fi
  fi
done < "$hfile"

if [[ "$hressucces" == "0" ]]
then
  echo -e "${red}[$crossm] Uh Oh! it looks like nothing was found!"
  echo -e "${red}You can try to use another Dir/Filelist and see if it works.${red}"
  read -p 'Press any key to continue: '
  jmpto ${menu}
fi

echo -e ""
echo -e "${green}[$checkm] Scan Completed! Check Above for Results.${red}"
read -p 'Press any key to continue: '
jmpto ${menu}
