#!/usr/bin/env bash

#==============================
#            Colors
#==============================
nc="\x1B[0m"              # Noclor      ${nc}
red="\x1B[1;31m"          # Red         ${red}
green="\x1B[1;32m"        # Green       ${green}
yellow="\x1B[1;33m"       # Yellow      ${yellow}
blue="\x1B[1;34m"         # Blue        ${blue}
purple="\x1B[1;35m"       # Purple      ${purple}
cyan="\x1B[1;36m"         # Cyan        ${cyan}
lightgray="\x1B[1;37m"    # LightGray   ${lightgray}
black="\x1B[0;30m"        # Black       ${black}
darkgray="\x1B[1;30m"     # DarkGray    ${darkgray}
darkred="\x1B[0;31m"      # DarkRed     ${darkred}
darkgreen="\x1B[0;32m"    # DarkGreen   ${darkgreen}
brown="\x1B[0;33m"        # Brown       ${brown}
darkblue="\x1B[0;34m"     # DarkBlue    ${darkblue}
darkpurple="\x1B[0;35m"   # DarkPurple  ${darkpurple}
darkcyan="\x1B[0;36m"     # DarkCyan    ${darkcyan}
white="\x1B[1;37m"        # White       ${white}

#==============================
#             UI
#==============================
checkm="\u2714"                         # Check Mark  ${checkm}
crossm="\u2716"                         # Cross Mark  ${crossm}

#==============================
#         jmpto func
#==============================
function jmpto
{
    label=$1
    cmd=$(sed -n "/$label:/{:a;n;p;ba};" $0 | grep -v ':$')
    eval "$cmd"
    exit
}

FILE=gdorkresult
if [ -f "$FILE" ]; then
    echo -e "${red}[*] Warning! the gdorkresult file already exists to avoid confusion with the urls please put the urls from gdorkresult into another file and delete gdorkresult"
    echo -e "${yellow}[!] Are you sure you want to continue?${blue}"
    read -p "Press any key to continue: "
fi

jmpto start
start:
clear
echo -e "${yellow}[*] Checking if lynx is installed"
if ! [[ -x "$(command -v lynx)" ]]
then
  echo -e "${red}[${crossm}] lynx is not installed."
  sleep 3
  echo -e "${green}[*] Installing lynx${darkblue}"
  sudo apt-get install lynx
  if [[ $? > 0 ]]
  then
      echo -e "${red}[${crossm}] Failed to install lynx."
      sleep 2
      echo -e "${yellow}[*] Please install lynx by yourself"
      sleep 2
      echo -e "${blue}[*] Exiting...${red}"
      exit
  else
      sleep 2
      echo -e "${green}[${checkm}] Successfully Installed lynx"
  fi
fi
sleep 2
echo -e "${green}[${checkm}] lynx is Installed"
sleep 2
menu:
clear
dorkdone=""
echo -e "${blue}  \x20\x20\x20\x5F\x5F\x5F\x20\x5F\x5F\x5F\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x5F\x20\x20\x20"
echo -e "${blue}  \x20\x20\x2F\x20\x5F\x5F\x7C\x20\x20\x20\x5C\x20\x5F\x5F\x5F\x20\x5F\x20\x5F\x7C\x20\x7C\x5F\x5F"
echo -e "${blue}  \x20\x7C\x20\x28\x5F\x20\x7C\x20\x7C\x29\x20\x2F\x20\x5F\x20\x5C\x20\x27\x5F\x7C\x20\x2F\x20\x2F"
echo -e "${blue}  \x20\x20\x5C\x5F\x5F\x5F\x7C\x5F\x5F\x5F\x2F\x5C\x5F\x5F\x5F\x2F\x5F\x7C\x20\x7C\x5F\x5C\x5F\x5C"
echo -e ""
echo -e "${yellow}1. Login Dork"
echo -e "${yellow}2. Admin Login Dork"
echo -e "${yellow}3. Site Cert Dork"
echo -e "${yellow}4. etc/passwd Dork ${red}"
echo -e ""
echo -e "${yellow}0. Exit GDork"
echo -e "${yellow}A. Delete gdorkresult file(if it exists)"
echo -e "${red}"
read -p "type a number: " dnum

if [[ "$dnum" == "" ]]
then
  jmpto menu
fi

if [[ "$dnum" == "0" ]]
then
  exit
fi

if [[ "$dnum" == "A" ]]
then
  clear
  if [[ -f "gdorkresult" ]]
  then
    echo -e "${yellow}[!] Are you sure you want to delete the gdorkresult file?${blue}"
    read -p "(y/n): " readyn
    if [[ "$readyn" == "y" ]]
    then
      rm gdorkresult
    else
      jmpto menu
    fi
  else
    echo -e "${red}[!] the gdorkresult file does not exist!"
    read -p "Press any key to continue: "
    jmpto menu
  fi
fi

read -p "type from which google page number you want the urls from: " dpgnum

if [[ "$dpgnum" == "" ]]
then
  echo -e "${red}[!] Please type a number!"
  read -p "Press any key to continue: "
  jmpto menu
fi

checkdpgnum='^[0-9]+$'
if ! [[ $dpgnum =~ $checkdpgnum ]]
then
  echo -e "${red}[!] The number you have typed is not a number!"
  read -p "Press any key to continue: "
  jmpto menu
fi

if [[ "$dpgnum" -gt "7" ]]
then
  echo -e "${red}[!] number execceds more than 7!"
  read -p "Press any key to continue: "
  jmpto menu
fi

# check the page number from dpgnum
if [[ "$dpgnum" == "7" ]]
then
  gpage=60
fi
if [[ "$dpgnum" == "6" ]]
then
  gpage=50
fi
if [[ "$dpgnum" == "5" ]]
then
  gpage=40
fi
if [[ "$dpgnum" == "4" ]]
then
  gpage=30
fi
if [[ "$dpgnum" == "3" ]]
then
  gpage=20
fi
if [[ "$dpgnum" == "2" ]]
then
  gpage=10
fi
if [[ "$dpgnum" == "1" ]]
then
  gpage=0
fi

if [[ "$dnum" == "1" ]]
then
  DORK="http://google.com/search?hl=en&safe=off&q=inurl%3Alogin.php&start=$gpage&filter=0"
  echo "======================================" >> gdorkresult
  echo "=== Login Dork === Page Number: $dpgnum  ===" >> gdorkresult
  echo "======================================" >> gdorkresult
  dorkdone="yes"
fi

if [[ "$dnum" == "2" ]]
then
  echo "============================================" >> gdorkresult
  echo "=== Admin Login Dork === Page Number: $dpgnum  ===" >> gdorkresult
  echo "============================================" >> gdorkresult

  DORK="http://google.com/search?hl=en&safe=off&q=inurl%3Aadmin-login.php&start=$gpage&filter=0"
  lynx -dump $DORK > gdork.tmp
  sed 's/http/\^http/g' gdork.tmp | tr -s "^" "\n" | grep http| sed 's/\ .*//g' > gdorkt.tmp
  rm gdork.tmp
  sed '/google.com/d' gdorkt.tmp >> gdorkresult
  rm gdorkt.tmp

  DORK="http://google.com/search?hl=en&safe=off&q=inurl%3Aadmin_login.php&start=$gpage&filter=0"
  lynx -dump $DORK > gdork.tmp
  sed 's/http/\^http/g' gdork.tmp | tr -s "^" "\n" | grep http| sed 's/\ .*//g' > gdorkt.tmp
  rm gdork.tmp
  sed '/google.com/d' gdorkt.tmp >> gdorkresult
  rm gdorkt.tmp

  DORK="http://google.com/search?hl=en&safe=off&q=inurl%3Aadminlogin.php&start=$gpage&filter=0"
  dorkdone="yes"
fi

if [[ "$dnum" == "3" ]]
then
  DORK="http://google.com/search?hl=en&safe=off&q=inurl%3A%2Fcerts%2Fserver.key&start=$gpage&filter=0"
  echo "=================================================" >> gdorkresult
  echo "=== Site Certificate Dork === Page Number: $dpgnum  ===" >> gdorkresult
  echo "=================================================" >> gdorkresult
  dorkdone="yes"
fi

if [[ "$dnum" == "4" ]]
then
  DORK="http://google.com/search?hl=en&safe=off&q=intitle%3A'index+of'+etc%2Fpasswd&start=$gpage&filter=0"
  echo "===========================================" >> gdorkresult
  echo "=== etc/passwd Dork === Page Number: $dpgnum  ===" >> gdorkresult
  echo "===========================================" >> gdorkresult
  dorkdone="yes"
fi

if [[ "$dorkdone" == "" ]]
then
  clear
  echo -e "${red}[!] Please provide a valid dork number!"
  read -p 'Press any key to continue: '
  jmpto menu
fi

lynx -dump $DORK > gdork.tmp
sed 's/http/\^http/g' gdork.tmp | tr -s "^" "\n" | grep http| sed 's/\ .*//g' > gdorkt.tmp
rm gdork.tmp
sed '/google.com/d' gdorkt.tmp >> gdorkresult
rm gdorkt.tmp

echo -e ""
echo -e "${green}[${checkm}] successfully got the urls from page $gpage and put them in '`pwd`/gdorkresult' "
quest1:
echo -e "${blue}"
read -p 'Do you want to do another dork? (y/n): ' readyn

if [[ "$readyn" == "y" ]]
then
   #rm gdorkresult
   jmpto menu
fi

if [[ "$readyn" == "n" ]]
then
   exit
fi

echo -e "${red}[${crossm}] you didnt provide a valid answer. only y or n can be answer!"
sleep 3
jmpto quest1
