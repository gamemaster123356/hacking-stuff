#!/usr/bin/env bash

#==============================
#            Colors
#==============================
nc="\x1B[0m"              # Noclor      ${nc}
red="\x1B[1;31m"          # Red         ${red}
green="\x1B[1;32m"        # Green       ${green}
yellow="\x1B[1;33m"       # Yellow      ${yellow}
blue="\x1B[1;34m"         # Blue        ${blue}
purple="\x1B[1;35m"       # Purple      ${purple}
cyan="\x1B[1;36m"         # Cyan        ${cyan}
lightgray="\x1B[1;37m"    # LightGray   ${lightgray}
black="\x1B[0;30m"        # Black       ${black}
darkgray="\x1B[1;30m"     # DarkGray    ${darkgray}
darkred="\x1B[0;31m"      # DarkRed     ${darkred}
darkgreen="\x1B[0;32m"    # DarkGreen   ${darkgreen}
brown="\x1B[0;33m"        # Brown       ${brown}
darkblue="\x1B[0;34m"     # DarkBlue    ${darkblue}
darkpurple="\x1B[0;35m"   # DarkPurple  ${darkpurple}
darkcyan="\x1B[0;36m"     # DarkCyan    ${darkcyan}
white="\x1B[1;37m"        # White       ${white}


#==============================
#      H@ck$kript Specfic
#==============================
sabover="1.0"                           # H@ck$kript Version
sabodev="zptgamer & gamemaster123356"   # H@ck$kript Devs
sabobuild="1000"                        # H@ck$kript Build

#==============================
#        H@ck$kript UI
#==============================
GHEIGHT=20                              # Gui Height  ${GHEIGHT}
GWIDTH=90                               # Gui Width   ${GWIDTH}
checkm="\u2714"                         # Check Mark  ${checkm}
crossm="\u2716"                         # Cross Mark  ${crossm}