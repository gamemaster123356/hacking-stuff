#!/usr/bin/env bash

FILE=../Data/vars.sh
if [ -f "$FILE" ]; then
    source ../Data/vars.sh
else 
    source ./Data/vars.sh
fi

clear
echo -e "${yellow}[*] Checking if TOR is installed"
if ! [[ -x "$(command -v tor)" ]]
then
  echo -e "${red}[${crossm}] TOR is not installed."
  sleep 3
  echo -e "${green}[*] Installing TOR${darkblue}"
  sudo apt-get install tor
  if [[ $? > 0 ]]
  then
      echo -e "${red}[${crossm}] Failed to install TOR."
      sleep 2
      echo -e "${yellow}[*] Please install TOR by yourself"
      sleep 2
      echo -e "${blue}[*] Exiting...${red}"
      exit
  else
      sleep 2
      echo -e "${green}[${checkm}] Successfully Installed TOR"
  fi
fi
sleep 2
echo -e "${green}[${checkm}] TOR is Installed"
sleep 2
echo -e "${yellow}[*] Checking if TOR is running"
if pgrep -x "tor" > /dev/null
then
    echo -e "${green}[${checkm}] TOR is running"
else
    echo -e "${green}[${crossm}] TOR is not running"
    echo -e "${green}[*] Starting TOR"
    sudo systemctl start tor
    if [[ $? > 0 ]]
    then
        echo -e "${red}[${crossm}] Failed to start TOR."
        sleep 2
        echo -e "${yellow}[*] Please start TOR by yourself"
        sleep 2
        echo -e "${blue}[*] Exiting...${red}"
        exit
    else
        sleep 2
        echo -e "${green}[${checkm}] Successfully started TOR"
    fi
fi
echo -e "${yellow}[*] Launching Auto TOR ip Changer"
sleep 3
clear
echo -e "${red}Please Don't use this on HTTP sites. On HTTP traffic between exit node and the site will be un-encrypted Your traffic will be visible if you use TOR in http."
echo -e "${yellow}In your browser, please use: [for socks5:127.0.0.1 port=9050] [also turn on proxydns socks5]"
echo -e "${blue}default ip changing seconds is 15 ${red}DO NOT SET IT TO 1"
echo -e "${green}#HsHZz${purple}"
read -p 'Type any key to start using this (type e to exit): ' readc
if [[ "$readc" == "e" ]]
then
   exit
fi
read -p 'Type how much time it should take the ip to change (seconds): ' ipsec
if [[ "$ipsec" == "" ]]
then
   ipsec="15"
fi
echo -e "${red}Fucking off ${purple}trackers...${nc}"
echo -e "${yellow}Fixed privacy.${nc}"
sudo service tor restart
echo -e "${green}Changed your ${yellow}ip addr--${red}"
#sleep 3
#usrip=$(wget http://ipecho.net/plain -q -O -)
#echo -e "${green}New ip address: ${usrip}"
while :
do
  sleep ${ipsec}
  sudo service tor restart
  echo -e "${green}Changed your ${yellow}ip addr--${red}"
  #sleep 3
  #usrip=$(wget http://ipecho.net/plain -q -O -)
  #echo -e "${green}New ip address: ${usrip}"
done