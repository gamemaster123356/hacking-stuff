#sub-menus

Hacking() {
    cmd=(dialog --clear --backtitle "H@ck\$kript" --title "[ Info ]" --menu "Select an option from the list:" "$GHEIGHT" "$GWIDTH" "$GHEIGHT")

    options=(
        Back "Back to main menu"
        wp-fuck "wordpress fuck it can enumerate users from wordpress"
    )

    choices=$("${cmd[@]}" "${options[@]}" 2>&1 >/dev/tty)

    for choice in $choices; do
        case $choice in
        Back) break ;;
        wp-fuck ) x-terminal-emulator -e ./Scripts/wp-fuck.sh ;;
        esac
    done
}

Security() {
    cmd=(dialog --clear --backtitle "H@ck\$kript" --title "[ Info ]" --menu "Select an option from the list:" "$GHEIGHT" "$GWIDTH" "$GHEIGHT")

    options=(
        Back "Back to main menu"
        Anti-Track "this script will change your TOR ip"
    )

    choices=$("${cmd[@]}" "${options[@]}" 2>&1 >/dev/tty)

    for choice in $choices; do
        case $choice in
        Back) break ;;
        Anti-Track ) x-terminal-emulator -e ./Scripts/Anti-Track.sh ;;
        esac
    done
}